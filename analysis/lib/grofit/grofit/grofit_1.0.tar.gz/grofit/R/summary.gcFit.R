summary.gcFit <-
function(object,...)
{
# object of class gcFit
data.frame(object$gcTable)
}

