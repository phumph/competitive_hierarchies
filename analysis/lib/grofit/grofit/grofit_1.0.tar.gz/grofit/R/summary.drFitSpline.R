summary.drFitSpline <-
function (object,...)
{
# object of class drFitSpline
data.frame(object$parameters)
}

