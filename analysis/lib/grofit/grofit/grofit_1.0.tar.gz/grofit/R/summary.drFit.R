summary.drFit <-
function(object, ...)
{
# object of class drFit
data.frame(object$drTable)
}

